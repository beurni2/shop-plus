# WO-4.2R — LE VISAGE · review packet

Founder verdict driving this order, verbatim: "still trash not looking like
real apps. these simple prototypes are even looking better than what you
have built."

Delivered: every existing screen in the three RN apps carries the real-app
visual layer, built ONCE per app on ui-tokens v2 (canon pin v0.6.0,
539dbc8a) — navigation chrome (header + hub tab bars as waypoint resets),
the component kit (RN primitives, ZERO new dependencies), token typography
with tabular numerals on every franc, the money heroes, celebration
produit_pret (boutik, the one ordered moment), spring-soft transitions,
and Séra's LandmarkCard signature. Navigation and money SEMANTICS are
byte-untouched (spine tests unmodified in all three repos; sera's custody
callback block sha-identical).

## Heads under review (branch `e4/wo-4.2r`) — DO NOT MERGE

| repo | base (main) | head | pin | build | verifier |
|---|---|---|---|---|---|
| boutik-plus | 84d81d8 | 48e53cd | 4070356 | 75a8445 + 8f859f8 | **PASS** (6 NB) |
| shop-plus | 6be3af2 | 96312a8 | 1e6ca21 | 52c114f | **PASS** (5 NB) |
| sera | db8848e | 3f33f10 | 3a57a72 | c1de1b9 | **PASS** (4 NB) |

## Budgets D17 (the face may not blow them — it did not)
- boutik: 682→683 modules · 1.48→1.49 MB android (+11.2 KB, verifier-measured)
- shop:   583→584 / 585→586 · 1.06→1.07 MB (~+10 KB)
- sera:   583→584 / 585→586 · 1.07→1.09 MB android (~+20 KB)
All serial isolated exports exit 0 ×2 platforms ×3 repos; cold proofs green
from committed bytes ×3 (install 0 · gates 0 · export 0).

## The before/after gallery — stated honestly (missing-state law) ⚠
The RN screens CANNOT be screenshot in this container without adding
react-native-web (+react-dom) as new dependencies — the order forbids new
deps unless force-quoted, and an RN-web render would not be device truth
(failure mode #9: demos well where it doesn't matter). The safest default
taken: the web galleries (buyer PWA 9/9 · dispatch console 4/4) re-captured
with ZERO PNG drift and the restyled RN journeys NAMED in their gaps; the
true before/after channel is the founder's phone — the WO-4.1 previews
were published from main, the WO-4.2R face publishes on merge.
FOUNDER OVERRIDE AVAILABLE: rule the react-native-web dev-only exception
in, and a PNG gallery harness for RN screens becomes its own small order.

## Flagged for founder rulings ⚠
1. boutik: the celebration also fires on corrective→pret while the product
   is still « correction en cours » (the MOMENT is the screen; the pending
   notice stays visible). Taste call — one line to restrict if ruled.
2. Cross-repo, upstream: v0.6.0 has no press/disabled-opacity or
   press-scale token — all three kits carry `scale: 0.98` + opacity
   multipliers as the only non-token style values (outside the DoD's
   colors/sizes letter; named by all verifiers). Proposed: tokens at the
   next platform-contracts rev.
3. Séra's LandmarkCard ships CTO-default text glyphs in the
   landmark.iconNames slots — the §4 « carte illustrée » needs the drawn
   assets (explicit follow-up so it doesn't silently become permanent);
   same debt class as emoji tab icons and the not-yet-built
   vérifié·scellé·livré badge language (named by the shop verifier as the
   visible remaining gap to « never seen before »).

## Contents
Per repo: diff.patch · branch-log.txt · journal-entry.md (committed,
verdicts verbatim) · verdict.md (the verifier's full report verbatim) ·
logs/ (gates, isolated dual exports, cold proofs) · gallery-states.json
(shop, sera — the named gaps).
