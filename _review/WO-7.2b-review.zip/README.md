# WO-7.2b — THE QR + THE COMPOSEUR · review packet

**Tier:** 🟠 AMBER · **Branch:** `e7/wo-7.2b` · **HEAD:** `da6f493` · **DO NOT MERGE** (founder review).
**Canon pin:** v0.9.7 = `508e94b1a6c1da8d29976759db74b7d0e5a24d2e` (release merge). ui-tokens content-prints **0.9.7**, warm + cold.

Founder ruled the composeur host = **Option (C)**: a sibling web surface `apps/reseller-kit` (vanilla TS + Vite + canvas, NO React/react-native-web/react-dom), sharing the vendored encoder, zero new deps. Built in the founder's order: (1) RN hub QR, (2) reseller-kit composeur, (3) lockfile law explicit, (4) device-scan JOURNAL line.

---

## What shipped (commits on this branch beyond `origin/main`)

- `0604db7` — re-pin the workspace to canon v0.9.7 (18 pins 04af4b5→508e94b; `dimension.qr` primitives; drift-check 0.9.7).
- `a351ecb` — the vendored QR encoder + the canon-form law (correct BY CONSTRUCTION vs ISO/IEC 18004).
- `de63897` — JOURNAL (encoder + re-pin; composeur host STOP-AND-FLAG).
- `233ff89` — **ITEM 1**: the on-screen QR in the RN share hub (`react-native-svg`, canon slug at the real origin, derived side).
- `e9dbd54` — **ITEM 2**: `apps/reseller-kit` the deterministic composeur (PWA path) + the kit link-out + the payload gate.
- `f0049ab` — JOURNAL (Option C, items 1–4).
- `da6f493` — tokenize the reseller-kit shell chrome (resolves the verifier's NON-BLOCKING NOTE 1: shell type px → type-scale CSS vars; a guard test forbids the regression). Card visual layer was already tokenized; no money/QR/composeur logic touched. Re-proven green warm + cold on this HEAD.

---

## The laws, and where each is held

| Law | Held by |
|---|---|
| **Money — SON prix** (Ten Laws #1, SP-I04/SP-I12) | `composeur.ts` `CardCopy` carries ONE `priceLabel` (a formatted figure) — no gross, no « à partir de », no struck rebate field. `composeur.test.ts` asserts the price appears once and refuses `à partir de`/`gross`/`barré`/`-N%`. |
| **SP-I03 — commission NOWHERE, supplier NOWHERE** | Structural: `CardInput`/`CardCopy` have NO field for a supplier identity or a commission amount — the composeur cannot paint them. Test asserts the `CardCopy` key set exactly, and no op text matches `commission/fournisseur/supplier/marge`. Same on the RN QR card. |
| **QR canon-form (Q2 ruling)** | `identity.ts` `isCanonIdentityUrl` (prefix + `/^[a-z]{2,12}-[0-9]{4}$/` slug); `DEMO_QR_URL = https://beurni2.github.io/shop-plus/v/aicha-4821`. Tests plant `/v/aicha`, `?ref=`, and `shopplus.bf` and assert REFUSED. Both the RN QR and the affiche QR encode exactly `DEMO_QR_URL`. |
| **`dimension.qr` primitives derived (not hand-picked)** | RN side = `(size + 2·quietZone)·moduleMin` (V4 → 164 dp); `qr-hub.test.ts` recomputes it from the tokens and forbids the literal `164` in source. Affiche QR at the 48 mm print side / ≥1.0 mm module — `composeur.test.ts` asserts sideMm ≥ 48 and moduleMm ≥ 1. |
| **Validity hint on EVERY output; QR on AFFICHE only** | `composeur.ts` pushes the validity op for all formats; the `qr` op only when `format === 'affiche'`. Tests assert validity on all three, 0 qr ops on story/carré, exactly 1 on affiche. |
| **No-scan fallback verbatim** | Catalog `share.qr_repli` / `card.qr_repli` = « Pas de scan ? Le code suffit — {code}. » templated on the ASCII short code `AICHA-4821`. Painted on the affiche + shown in the RN hub. |
| **Determinism** | `composeur.ts` is pure (no `Date`, no random). Test asserts byte-identical display list across two calls for every format/model. |
| **French Voice §10.5** | All strings in the i18n catalogs, register-tagged. copy-lint: reseller-app **90/0**, reseller-kit **21/0**. Catalog tests forbid inline French in the shell/composeur. |
| **Encoder shared, not forked; zero new deps** | reseller-kit imports the encoder via `@qr/*` → `../reseller-app/src/qr/{encoder,identity}.ts` (ONE source). No second encoder copy under `apps/reseller-kit`. Deps = `@platform/i18n` + `@platform/ui-tokens` only (same as buyer-pwa). |
| **Tokens only** | `QrCode.tsx` + `composeur.ts` take colours from `@platform/ui-tokens` (`theme.colours` / `shopColour`); no hex/rgb literals. |

---

## Evidence

- `logs/warm-gates.log` — `run-gates.sh` **ALL GATES GREEN** (rc=0). Includes: turbo typecheck (12 pkgs) + test (17 tasks), copy-lint reseller-app + buyer-pwa + **reseller-kit 21/0**, the payload gate measuring **both** surfaces (buyer-pwa 74 239 B · **reseller-kit 7 232 B** compressed, each < 300 KB), lockfile-url-form (positive green, negative fixture fires), drift-check 0.9.7, Playwright 43/43.
- `logs/cold-proof.log` — **isolation-evidence law**: fresh clone of the committed bytes (`f0049ab`) into an isolated tree, fresh HOME, isolated store + XDG cache, Playwright at the preinstalled chromium. `pnpm install --frozen-lockfile` **rc=0** (cloned lockfile: **0 ssh-form, 0 proxy-leak**), ui-tokens **0.9.7**, `run-gates.sh` **rc=0 — ALL GATES GREEN**. Both app lines present (reseller-app encoder + reseller-kit composeur).
- `logs/cold-proof-pure-baseline.log` — **ITEM 3**: the frozen install re-run with the ambient `GIT_CONFIG` git@→https normalization UNSET — only the proxy `insteadOf` + `credential.interactive=false` present. `pnpm install --frozen-lockfile` **rc=0**, 0 ssh-form, 0 proxy-leak. Proves the committed lockfile needs NO normalization to install cold.
- `screenshots/` — the composeur rendered through the preinstalled Chromium: `kit-story.png` (9:16, no QR), `kit-carre.png` (1:1, no QR), `kit-affiche.png` (A5, QR + legend + code + no-scan fallback), `kit-affiche-nuit.png` (the ink model — QR keeps its own paper quiet zone).
- `diff/wo-7.2b.stat.txt` · `diff/wo-7.2b.full.diff` — the full branch delta vs `origin/main`.
- `WO-7.2b-VERIFIER-VERDICT-verbatim.md` (repo `_review/`) — the fresh-context verifier's verdict, copied VERBATIM (never rewritten).

---

## ITEM 3 — the lockfile law (authoring hygiene vs cold proof)

Adding the `apps/reseller-kit` importer forced a lockfile regen. Under the plain proxy baseline the regen re-leaked 9 `git+https://git@github.com:` forms for the two newly-referenced deps (`@platform/i18n`, `@platform/ui-tokens`) — the WO-7.0 defect. **Authoring hygiene:** regenerate on a fresh store under a normalization gitconfig (`git@`/`ssh` → `https` FIRST, then `https` → proxy) → the committed lockfile is **0 ssh-form, 0 proxy-leak**; the diff is minimal (the importer block only; every git dep in portable https-form). That normalization config is LOCAL, never committed. **Cold proof** runs on the credential-only baseline (proxy `insteadOf` only, no normalization) — `cold-proof-pure-baseline.log` shows the frozen install rc=0 there.

## ITEM 4 — the device scan is a named POST-MERGE production check

In-repo end-to-end decode is not run (Chromium's `BarcodeDetector` is unimplemented on Linux; a decoder dep would break the zero-dep law). Encoder correctness rests on the ISO/IEC 18004 cross-checks (RS generators deg 10/18/26 + all 8 ECC-M format-info words vs the published tables) + structure. **A physical device scan of the affiche/hub QR is the post-merge production check, and it exercises the `/v/aicha-4821` deep link in the same action** (scan → land on the canon vitrine).

---

## Honest limits / notes for the founder

- **The product photo is a designed sable placeholder** — the demo carries no real product image bytes; the composeur blits the reseller's photo into that box in production. The composition laws (price/validity/code/QR/no-supplier) are what the tests pin.
- **The short code renders ASCII `AICHA-4821`** on both surfaces (matching the shipped RN hub and the canon slug) rather than the ledger's diaeresis form « AÏCHA-4821 » — a poster must not carry a divergent form from the RN hub (Q2 spirit). Flagging the copy choice.
- **The kit link-out is a sandbox link** (`shop-plus.demo/kit`, honestly « d'essai ») — the same visibly-fictional convention as every demo link in the reseller-app; a real deployed kit URL is a separate deployment slice (no workflow shipped here).
- **NUIT / 4:5 carré / motion polish** are present-but-minimal: NUIT (ink) works; the spec's 4:5 carré variant and cross-fade motion are not in this slice's scope (the WO named story · carré · affiche + canvas render + price/validity/QR/fallback).
