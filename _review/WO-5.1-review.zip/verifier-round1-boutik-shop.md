# WO-5.1 verifier round 1 (boutik 0a64480 + shop 0496b99), VERBATIM

I have everything I need. All four attacks executed with my own hands, plus the extras. Let me confirm the RN rect geometry matches (it does: cadenas `Rect x={5.5} y={10.5} width={13} height={9.5} rx={2.5}` and zone's 4 rects match the reference verbatim) and compile the ruling.

Root cause of the PWA icon defect, for the record: in `scripts/gen-icons.py` line 44, `ET.tostring(el)` serializes each SVG child with an auto-assigned namespace prefix (`<ns0:path xmlns:ns0="http://www.w3.org/2000/svg">`); the following `.replace(NS, "")` only strips the Clark-notation `{http://www.w3.org/2000/svg}` form, which never appears in serialized output — so the prefix survives. The RN path uses `el.tag.replace(NS,"")` on the raw tag and is clean.

---

## Ruling on WO-5.1 — the Grand Teint SUBSTRATE

**Attack 1 — cold start re-measured, RN method honesty.** Built `@shop-plus/buyer-pwa` (vite, 20 modules), served `dist`, ran BOTH the committed spec (`e2e/font-cold-start.spec.ts`, 2 passed) and my own independent throttled harness (4× CPU, 1.5 Mbps/300 ms). Independent numbers: **FCP = 392 ms, font `responseEnd` = 844 ms → first paint precedes font-ready by 452 ms** (font does not gate FCP); **CLS = 0, 0 shift entries**; price box identical before/after swap (top 24→24, h 46→46). The web proof is honest and reproduces. RN `COLD-START.md` is honest: it states plainly "There is no Android Go device or emulator in this sandbox … the real device number can only come from the founder's device," logs the 167 KB byte cost, and rests on a non-blocking-by-construction mechanism — **no faked device millisecond number.**

**Attack 2 — 3 icons byte-match.** coche/moto/argent geometry appears verbatim in RN `icons.tsx` and in the PWA `grand-teint-icons.ts` strings; currentColor honored; RN default `size = 20`, PWA parameterized `(size = 20)`. RN rects (cadenas, zone — not covered by the RN test) also match the reference verbatim. Geometry text: clean.

**Attack 3 — blank path.** Web: aborting the woff2 → price still renders "12 500 F", real box 1232×46, `archivoActive=false`, CLS=0 — no blank screen. RN `src/ui/fonts.ts` is pure data (family, `System` fallback, weight→file map); no `expo-font`/`loadAsync`/`useFonts`/`require` — gates nothing. **But the same block-test on the icons exposed the defect below.**

**Attack 4 — measurements + scope.** woff2 = **30352 B** (≪ 300 KB gate); RN TTF total = **170704 B** with all five sha256 matching BUILD.md (within 180–240 KB). Exactly two deps added per RN app (`react-native-svg 15.12.1` + `expo-haptics ~15.0.8`); buyer-pwa `package.json` untouched. Unwired confirmed: `App.tsx`/`index.ts` (both RN) and `main.ts` (PWA) import none of the new modules, and the built `dist` JS contains zero `Archivo`/`grandTeintIcon` references. `design-reference/grand-teint` is byte-identical to the bundle source (`diff -rq` exit 0, both repos). WO-4.4 `buyer-pwa/src/icons.ts` untouched. New vitest suites pass (boutik 8 / reseller 8 / buyer-pwa 7). `run-gates.sh` exits 0 in both repos (shop runs the e2e incl. cold-start). The "dual-export 698/700 · 584/586" figures are **not reproducible in-sandbox** — no committed script computes them — but the property they proxy (unwired, bundle unchanged) is verified directly.

---

VERDICT: FAIL

① (blocker) **Every one of the 26 PWA inline icons in `shop-plus/apps/buyer-pwa/src/grand-teint-icons.ts` renders nothing.** The generator emits `<ns0:path xmlns:ns0="…">`-prefixed elements. Injected via the repo's own consumption pattern (`checkout-view.ts` interpolates `${lockIcon()}` → `main.ts` sets `section.innerHTML`), the HTML parser creates elements with localName `ns0:path` (not SVG `path`): I measured `getElementsByTagNameNS(SVG,'path')=0` and **`getBBox` = 0×0**, versus the working WO-4.4 lock icon (rect+path, bbox 14×17) in the identical harness. Concrete failing scenario: the next PWA type slice does `el.innerHTML = grandTeintIcon.coche(20)` exactly as WO-4.4 does for lock/scooter, and the buyer sees an empty box where the « vérifié » checkmark belongs. Root cause: `scripts/gen-icons.py:44` — `ET.tostring` auto-prefixes the namespace and the subsequent `.replace(NS,"")` strips only the Clark-notation form, which is absent from serialized output; the outer `<svg>` also lacks `xmlns`, so a standalone/data-URI consumption would fail too. RN icons are unaffected (proper `<Path>/<Circle>/<Rect>`). The defect is currently latent (substrate unwired) and masked by a vacuous test — see ②. Fix is a one-liner (`ET.register_namespace('', 'http://www.w3.org/2000/svg')` before `tostring`, or strip the `ns0:` prefix + add root `xmlns`), then regenerate.

② (blocker, coupled to ①) **`buyer-pwa/test/grand-teint-web.test.ts` "carries the design-reference geometry (byte-identity)" asserts nothing about rendering** — it only greps the string for `d="…"`, so it stays green while every icon it "protects" is invisible. This is canon failure-mode #7 (a test that passes without asserting its invariant); it is why ① shipped. Add a jsdom/browser assertion that an injected icon yields recognized SVG geometry (non-zero `getBBox`/`getElementsByTagNameNS` count).

NB① The RN geometry test (`test/grand-teint.test.ts`, both repos) asserts path `d` and circle cx/cy but not `rect` geometry; the rects are in fact correct (verified cadenas + zone vs reference), so this is coverage-completeness only.

NB② `font-check.html` under `public/` carries hardcoded hex (`#FAF7F2`, `#26221C`); it is a measurement harness, not product, and the gate suite passes — acceptable, but worth a one-line note that it is exempt by being a harness.

NB③ The U+202F narrow-no-break-space gap (Archivo lacks the glyph `Intl.NumberFormat('fr-FR')` emits) is honestly disclosed in `BUILD.md` and deferred to the next type slice — not introduced by this review, already flagged.

Everything except the PWA icon module is clean, honest, and reproduced. The cold-start proof — the reason the slice exists — holds under my own instrumentation. The blocker is confined to the PWA icon deliverable and its false-confidence test; both are fixed by repairing `gen-icons.py` and regenerating.