# WO-7.2a review packet — S3 Découverte · S7 Ventes/Clientes · the price-validity hint (🟠 AMBER) — IN REVIEW, NOT MERGED

Branch `e7/wo-7.2a` · pin held `04af4b5` (v0.9.4).

## Contents
- **DIFF.patch** — the whole slice vs `main`.
- **VERIFIER-VERDICT-verbatim.md** — the fresh-context verifier's testimony, copied verbatim (PASS: no invariant violation; four non-blocking findings).
- **JOURNAL-committed.md** — the committed book (WO-7.2a entries + the verifier-fix entry at the tail).
- **logs/branch-log.txt** — commit-by-commit stat.
- **logs/warm-gate-log.txt** — `run-gates.sh` in the working tree → ALL GATES GREEN.
- **logs/cold-gate-log.txt** — the FULL cold proof from committed bytes (fresh HOME + isolated store/cache): `export HOME`, the `insteadOf` auth line, fresh store/cache, `git clone`, `pnpm install --frozen-lockfile rc=0`, ui-tokens 0.9.4, `run-gates.sh rc=0` → ALL GATES GREEN (both app lines: reseller ventes 12/12 + buyer boutiques 13/13 + 43 e2e).
- **decouverte-defaut.png · decouverte-saisie.png** — S3 rendered (the fixed-clock gallery).

## What shipped
- **S3 Découverte** (buyer PWA, /boutiques): the store directory — stores never a feed (SP-I05), the deterministic order rendered on-screen (SP-I11), no price/photo in the list, no supplier/commission; six designed states; cards → canon /v/{slug}; root + vitrine-footer entries.
- **S7 Ventes/Clientes** (reseller RN): the sales list + detail — net-first everywhere, commission unrepresentable, first-name-only relay, every franc reconciled through the pinned waterfall (Mariam = §5.4 baseline); seven states via presenter tests.
- **The validity hint** (closes the WO-7.1 deferral): « Prix du {date} — le lien dit le prix du jour. »; the card-authority gate now requires the render date.

## Verifier findings — all four ADDRESSED (session commentary; NOT the verifier's words)
The verifier PASSED with no invariant violation. Its four non-blocking findings were all fixed in commit `95b46c7`:
- **P1 (fixed)** — S7 chip tones collapsed to grey (`info===muted`). `chipTone` now matches the mockup: PROBLÈME→bad, **À LA PORTE→warn (amber)**, LIVRÉE→**ink** (a new `ink` ChipTone), middle states muted — the closest-to-door emphasis is restored.
- **P2 (fixed)** — LIVRÉE was success-green + a false « ink « ok » » comment; now the `ink` tone + a correct comment (never money-green). (The kit's dot+text chip vs the mockup's filled chip is a pre-existing kit/mockup style divergence, flagged for a kit pass, not introduced here.)
- **P3 (reframed)** — the deferred S7 4-tab bottom nav is deferred because it references screens not built this slice (a reseller Découverte tab, a vitrine-preview tab); Q1 compounds but does not govern it. Corrected in the JOURNAL.
- **P4 (fixed)** — the Metro-safety scan now covers `src/sales/ventes.ts`.
- Minor: the accueil→ventes demo-nav button now uses a short « Mes ventes » (`ventes.nav`, from the mockup's « SHOP+ · MES VENTES » header).

## Flags standing for the founder (journaled, not invented)
- S3 count « 6 » vs 5 specified stores (6th not in the handoff → ships 5).
- The four non-Aïcha vitrines are follow-up demo data.
- The S7 4-tab bottom nav is deferred (references out-of-scope screens).
- QR + composeur stay WO-7.2b (gated on Q3–Q6).

## Evidence headline
Warm + cold suites green (cold = committed bytes, install rc=0) · verifier PASS · reseller 67/67 · buyer-pwa 94/94 · e2e 43 · copy-lint 84/137 · payload 73,960 B < 307,200.

## Frozen-file accounting (CTO pre-merge condition)
`src/journey.ts` changed for the first time since the WO-7.0 freeze — legitimate (S7 is
an ordered new screen; the WO-7.0 freeze was that slice's semantics guard, and 7.2a is
the design-gated split it reserved), now on the record. **Additive-only** (`git diff
origin/main..HEAD -- src/journey.ts`): the `Screen` union gains `ventes` + `vente_detail`
(appended); `JOURNEY.accueil` gains `ventes` **appended** (`['opportunites','gains']` →
`['opportunites','gains','ventes']`, the two existing edges byte-identical); two new
edges `ventes: ['vente_detail']` + `vente_detail: []`. Every pre-existing edge is
byte-identical; none removed or reordered. `journey-spine.test.ts` 5/5 green, unchanged.
Standing anchor amended: « journey.ts byte-equal to main » → « delta is EXACTLY the
ordered additive extension; existing edges byte-identical » — any frozen-file touch is
surfaced or the slice stops. (earnings.ts + demo/store.ts stay byte-equal to main.)
