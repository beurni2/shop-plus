# COPY — WO-7.2, les nouvelles chaînes
### French Voice · 6ᵉ année · chaque chaîne taguée · s'ajoute au catalogue v1.0.0

## S5 · L'indice de validité du prix (item 6 — la chaîne canon)

| Où | String | Register |
|---|---|---|
| pied de carte (story · carré · affiche), avec la date du rendu | « Prix du 13 juillet — le lien dit le prix du jour. » | money |
| composeur, sous l'aperçu | « La carte garde le prix d'aujourd'hui. Votre prix change ? Créez une nouvelle carte — le lien, lui, dit toujours le prix du jour. » | money |

*Loi tenue : zéro urgence fabriquée — l'indice dit où est la vérité (le lien), il ne presse personne.*

## S3 · Découverte des boutiques (PWA acheteuse)

| String | Register |
|---|---|
| « LES BOUTIQUES » | neutral |
| « Des vendeuses vérifiées, livrées par Séra. Le paiement est protégé. » | money |
| placeholder « Cherchez une vendeuse ou un quartier » | neutral |
| la phrase de l'ordre (affichée à l'écran) « Classées par dernière mise à jour — la plus récente d'abord. » | neutral |
| chips zones « TOUTES · ROOD WOKO · GOUNGHIN · DASSASGHO · TANGHIN » | neutral |
| compte « {n} boutiques » · saisie « {n} boutiques — pour “{q}” » | neutral |
| carte boutique « Vérifiée » · « {zone} · {n} produits · mise à jour {quand} » | neutral |
| aucun résultat « Rien pour “{q}” — essayez le nom de la vendeuse, ou un quartier. » | selling |
| hors ligne « Hors ligne : la liste affichée est celle d'hier soir. » | money |
| erreur « La liste n'a pas pu se charger. Rien n'est perdu — réessayez. » · « RÉESSAYER » | money / neutral |
| pied « Son prix est le prix — livré par Séra, paiement protégé. » | money |

## S7 · Mes ventes / clientes (Shop+)

| String | Register |
|---|---|
| « MES VENTES — LES PROBLÈMES D'ABORD » | neutral |
| vide « Aucune vente en cours. » — « Partagez votre vitrine — c'est elle qui remplit cette page. » · « PARTAGER MA VITRINE » | selling |
| chips d'état « PAYÉE » · « EN PRÉPARATION » · « EN ROUTE » · « À LA PORTE » · « LIVRÉE » · « PROBLÈME » | neutral |
| problème (encart) « Signalé à l'inspection — le bureau des exceptions s'en occupe. La commande reste protégée ; votre net attend, il n'est pas perdu. » | money |
| détail « VOTRE GAIN NET » (d'abord, toujours) — « Réglé après livraison validée. » · « SON PRIX : 11 500 F » | money |
| relais « Vous ne voyez jamais son numéro — le relais s'en charge. » | money |
| hors ligne « Hors ligne : vos ventes affichées sont celles d'hier soir. » | money |
| erreur « Vos ventes n'ont pas pu se charger. Rien n'est perdu — réessayez. » · « RÉESSAYER » | money / neutral |

## QRVitrine (hub · affiche)

| String | Register |
|---|---|
| hub, bloc en personne « FAITES SCANNER — EN PERSONNE » | neutral |
| hub « Votre cliente scanne — elle arrive sur votre vitrine. La vente vous revient. » | selling |
| légende sous le QR (carte · affiche) « SCANNEZ — OU TAPEZ LE CODE » | neutral |
| repli sans scan « Pas de scan ? Tapez shopplus.bf/v/aicha » | neutral |

*Lois : le QR n'est jamais seul (icône + mot → QR + code + lien en clair) · jamais une cible tactile · l'attribution survit sans scan (le code).*
