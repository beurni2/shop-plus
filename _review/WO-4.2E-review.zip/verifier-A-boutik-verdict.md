# WO-4.2E verifier A (boutik, at 0bccd27) — VERBATIM

All mandated attacks and checks are complete. Every result is grounded in a run I performed against the actual compiled `normalization.ts` and the repo test suite.

## What I ran and found

**Suite + types (my run):** `pnpm --filter supplier-app test` → 67/67 passing (exif-strip.test.ts 8, ui-studio.test.ts 18, capture-incident.test.ts 15, others). `typecheck` → clean, no output.

**Attack 1 — crafted real-grammar EXIF JPEGs through the full path** (compiled normalization.ts with the repo's esbuild@0.25.12; my OWN independent header walker, not the repo's). Cases (a) iOS classic APP0+APP1(Exif+TIFF+GPS IFD), (b) APP1-XMP, (c) APP13/Photoshop, (d) COM, (e) late APP1 after DHT (with DRI kept), (f) three APP1s + progressive SOF2, (g) `FF E1 'Exif\0\0'` planted INSIDE the entropy stream, plus bonus APP2-ICC/APP14-Adobe preservation. For every case: `base64ToBytes → stripJpegMetadata → assertExifFree` did not throw; my walker confirmed no APP1/APP13/COM marker remains in the header; output equals input-minus-dropped-markers byte-for-byte; DQT/SOF/DHT/SOS/entropy identical; exactly one SOS; SOS→EOI tail verbatim; the data-URI payload decodes back to exactly the stripped bytes. Case (g)'s fake-Exif entropy bytes are preserved verbatim and the output still passes assertExifFree (scanner stops at SOS). **ALL PASS.**

**Attack 2 — smuggle through ignored markers.** `STRIPPED_MARKERS` is a DROP-list `{APP1, APP13, COM}`; everything else in the header is kept. Confirmed survivors: APP0-non-JFIF, APP2-non-ICC (MPF/FPXR), APP3–APP12, APP15, DAC, and trailer-after-EOI. For **every** survivor `assertExifFree` does NOT throw — i.e. none breaks the gate as tested. An APP1 whose length lies short correctly REFUSES (strip_failed). Nested `FFE1-Exif` bytes riding inside a kept APP2/ICC payload survive but do not trip the scanner (payload not re-scanned).

**Other checks (all run):** clean JPEG passes byte-identical; the 5 named malformed classes + my own (len=0, len=1, SOI-only, `FF FF`-then-nothing) all throw `strip_failed`; `bytesToBase64` matches `Buffer.from().toString('base64')` for all 301 sizes (every %3 remainder) + 2000 random buffers, round-trips through `base64ToBytes`; full chain runs with `globalThis.atob` deleted (EXIF dropped, URI round-trips, `/9j` prefix); capture.ts ships `data:image/jpeg;base64,${bytesToBase64(stripped)}` and the assignment `uri: derivative.uri` appears nowhere (only a comment references the name); normalization.ts is a pure module, zero imports; no package.json/lockfile changed on the branch; diff touches only 5 files — WALKTHROUGH.md, capture.ts, normalization.ts, exif-strip.test.ts, ui-studio.test.ts — no money/services/journey/demo. The ui-studio WYSIWYG pins are real source-text assertions on the strip+assert+data-URI shape.

Founder's actual incident (iOS encoder leaking front-of-file APP1-Exif) is fully closed: the whole APP1 class is dropped, and assertExifFree on the stripped bytes is a genuine post-condition backstop.

---

VERDICT: PASS

Blockers: none.

- NB① — normalization.ts:218 (`STRIPPED_MARKERS`) + :260. The stripper is a DROP-list over the header, not a KEEP-list, so it preserves every non-{APP1,APP13,COM} APPn. A nonstandard/hostile encoder can smuggle arbitrary bytes (incl. device/location text) through APP0-non-JFIF, **APP2-MPF/FPXR (a real iOS segment)**, APP3–APP12, APP15, or DAC and it survives untouched. Concrete: attack2 shows an `APP12`/`APP2-MPF` payload `secret-device-iphone15` present in output with `assertExifFree` not throwing. Not a break of the gate as TESTED (APP1-Exif scan) — residual metadata surface. Docket a switch to an allowlist (SOI/APP0-JFIF/APP2-ICC/APP14-Adobe/DQT/SOF*/DHT/DRI/SOS) if the threat model ever includes a hostile encoder; for the benign-iOS-leak threat the drop-list suffices.

- NB② — normalization.ts:241-246 (SOS branch copies `bytes.subarray(i)` to end verbatim). Consequence: (a) bytes appended after EOI (classic stego trailer) ship unchanged, and (b) any metadata placed after the first SOS (e.g. between scans of a progressive JPEG) is neither stripped nor seen by assertExifFree, which shares the same first-SOS stop boundary. Concrete: attack2 trailer `APPENDED-AFTER-EOI…` survives in the output. Both stripper and scanner agree on the SOS boundary, so no false failure — residual surface only. expo `saveAsync` emits baseline JPEG with front-of-file EXIF, so unreachable in practice.