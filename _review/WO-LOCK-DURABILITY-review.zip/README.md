# LOCK-DURABILITY — the durable attribution lock · review packet

**Tier:** 🔴 RED (money-attribution anchor) · **SP#001 slice C** · **Branch:** `e7/wo-lock-durability` · **code HEAD:** `a266a83` (JOURNAL `920bd20` doc-only beyond it) · **DO NOT MERGE.**

**The finding (ratified):** SP-I09b.3 — "once locked … immutable, first-lock-wins" — was held by a private in-memory `Map` (`services/attribution-service/src/lock.ts`). A process restart erased every lock; there was nothing to replay from. This slice makes the lock **durable and replayable**, proven **across a restart**.

---

## Approach — substrate by derivation (stated first)

Séra's precedent for atomic single-authority state is Cloudflare Workers + Durable Objects (Sera-Build-Spec:57, "single atomic assignment lease"). shop-plus's INSTANCE of that class is the **commerce-core reservation DO** (`packages/commerce-core/worker/reservation-do.ts` + miniflare 4 + workerd + esbuild bundle + e2e). I mirror it 1:1:

| reservation DO (precedent) | attribution lock (this slice) |
|---|---|
| `src/reservation.ts` — pure `decideReservation(current, cmd)` | `src/lock-core.ts` — pure `decideLock(current, claim)` (no `@platform/contracts`; the worker bundle stays clean) |
| `worker/reservation-do.ts` — `QuoteReservationDO` per `quoteId`, `state.storage` | `worker/attribution-lock-do.ts` — `AttributionLockDO` per **`checkoutRef`**, `state.storage` |
| `reservation-do.e2e.test.ts` — workerd, within-instance persistence only (`:93-99`) | the 7 e2e tests, each crossing a **dispose/recreate RESTART** (`durableObjectsPersist`) — the gap the precedent never exercised |

**Two gaps found & closed by derivation (not invention):** (1) the harness lived in commerce-core, not attribution-service — wired the SAME harness in (miniflare/esbuild/@cloudflare/workers-types devDeps, **all already resolved for commerce-core → zero new external packages**). (2) No restart-survival proof existed — I **probed** `durableObjectsPersist` + dispose/recreate first (`miniflare-persist-probe.mjs` → `RESULT: SURVIVES-RESTART`); had it failed this would have been a STOP-AND-FLAG.

---

## The laws, and where each is held

| Law | Held by |
|---|---|
| **Semantics BYTE-UNCHANGED** (first-lock-wins · immutable · collision→`reconciliation.alert.v1`) | `AttributionLockBook` (`lock.ts`) now decides through `decideLock` + shared canon-event builders; `test/lock.test.ts` **4/4 green, unchanged**. `decideLock` returns exactly `created`/`idempotent`/`collision`. |
| **Durable (real, not a shim)** | `AttributionLockDO` persists the lock via `state.storage.put/get` (`attribution-lock-do.ts`), addressed by `idFromName(checkoutRef)`; e2e runs on REAL workerd (Miniflare) with on-disk `durableObjectsPersist`, each test crossing a real `dispose()`+recreate. |
| **Replay rebuilds an identical book** | the replay test re-reads every checkout's persisted lock after a restart and `JSON.stringify`-compares the projection (`attribution-lock-do.e2e.test.ts`, REPLAY test). |
| **Never attributes platform (SP-I09b.4)** | `decideLock`: `created`/`idempotent` carry the claim's own reseller, `collision` carries the ORIGINAL locked reseller unchanged; an absent lock reads `null` (nobody). The e2e asserts the stored reseller never matches `/platform|shop-plus/` and an untouched checkout is `null`. |
| **Per-aggregate versioning (surfaced difference)** | a collision bumps a per-checkout **persisted** version (the durable-correct form of the book's in-memory global counter); same event shape/payload, `seq` is per-aggregate. |
| **FORBIDDEN honored** | `resolveAttribution` (`resolution.ts`) byte-UNCHANGED · préséance untouched · `order-spine.ts`/`quote-issuance.ts`/`journey.ts`/`earnings.ts` byte-FROZEN (empty diff). Diff touches only `services/attribution-service/*` + `pnpm-lock.yaml`. |

---

## Evidence

- `logs/red-proof.log` — **adversarial-tests-first**: the 7 e2e run against a throwaway NON-DURABLE (in-memory) DO variant → **6 of 7 FAIL** (every restart assertion), proving the tests catch the durability gap before the durable impl makes them pass. The variant was never committed.
- `logs/warm-gates.log` — `run-gates.sh` **ALL GATES GREEN** (rc=0), incl. `attribution-lock-first-wins` (positive + negative fixture) and `attribution-tamper` (the refactor kept the book byte-green).
- `logs/cold-proof.log` — isolation-evidence law: fresh clone of `a266a83`, credential-only baseline HOME, isolated store + cache. `pnpm install --frozen-lockfile` **rc=0** (0 ssh-form, 0 proxy-leak), ui-tokens 0.9.7, `run-gates.sh` **rc=0 — ALL GATES GREEN**.
- `logs/cold-both-lines.log` — **both workerd DO e2e lines green cold**: attribution-lock `7/7` (with restart survival) · reservation `7/7`.
- `miniflare-persist-probe.mjs` — the durability probe that grounded the approach.
- `diff/lock-durability.stat.txt` · `diff/lock-durability.full.diff` — the full diff (8 files, +563/−63; lockfile +9).
- `WO-LOCK-DURABILITY-VERIFIER-VERDICT-verbatim.md` (repo `_review/`) — the fresh-context verifier's verdict, copied VERBATIM.

---

## Chain context (SP#001 — THE SELLER #001 SPINE)

This is **slice C**. On packet ship I proceed down the chain: **SP#001-A** (storefront aggregate) → **SP#001-B** (listings + the live projection) → **SP#001-D** (la première commande réelle), each branching from the prior head, packets per slice, no waiting on rulings. **RESELLER-I18N** is re-queued to the tail. Every slice: full packet · cold proof both lines · fresh-context verifier · DO NOT MERGE.

## Honest notes

- **The DO is the durable authority; the in-process `AttributionLockBook` remains** as the byte-unchanged in-memory book for callers/unit tests. The service seam that swaps callers onto the DO (wiring the checkout path to the durable authority) is the natural next touch — this slice makes the durable authority EXIST and PROVES it survives a restart; it does not yet re-point the (still-stub) checkout seam. Flagged, not hidden.
- **The collision `seq` is per-aggregate on the durable path** vs the book's per-book global counter — a deliberate, surfaced difference (per-aggregate versioning is the durable-correct form); the alert's name + payload are identical on both paths.
