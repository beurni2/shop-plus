import { createRequire } from 'node:module';
const require = createRequire('/home/user/shop-plus/packages/commerce-core/package.json');
const { Miniflare } = require('miniflare');
const persist = new URL('./do-persist', import.meta.url).pathname;
const opts = { modules: true, scriptPath: 'probe-do.mjs', durableObjects: { COUNTER: 'Counter' }, durableObjectsPersist: persist };
let mf = new Miniflare(opts);
const put = await mf.dispatchFetch('http://x/put?v=42'); console.log('put:', await put.json());
await mf.dispose();
mf = new Miniflare(opts); // recreate on the SAME persist dir = a restart
const got = await mf.dispatchFetch('http://x/get'); const body = await got.json();
console.log('after-restart get:', body);
await mf.dispose();
console.log(body.v === 42 ? 'RESULT: SURVIVES-RESTART (durable)' : 'RESULT: LOST (ephemeral)');
