# WO-4.4 fresh-context verifier — round 2, DELTA bcf6770..0f33843, VERBATIM

All delta verifications complete. Final report on the delta (bcf6770 → 0f33843).

## Evidence (all run by me on HEAD 0f33843)

| Check | Result |
|---|---|
| `pnpm --filter @shop-plus/buyer-pwa test` | **59/59 passed** (was 56; +1 product esc, +1 location esc, +1 compile-guard test) |
| `pnpm --filter @shop-plus/buyer-pwa typecheck` | clean |
| `pnpm exec copy-lint apps/buyer-pwa/i18n/catalog.json` | **102 entries, 0 violations** |
| `node scripts/gates/pwa-payload-budget.mjs` | **TOTAL 12,109 B** / JS 11,707 B — exactly as claimed, PASS |
| e2e (`PW_EXECUTABLE=/opt/pw-browsers/chromium … test:e2e`) | **32/32 passed** |
| Delta scope | 11 files, all `apps/buyer-pwa/` + `gallery/` — reseller-app/packages untouched |

## Per-finding verification

**NB① — CLOSED.** `esc()` (`src/format.ts:7-11`) escapes `& < > " '` — the full attribute-breakout alphabet. Every model-derived string interpolation in the new render layer is now wrapped: `landmark`/`directions`/`phone` (`location-view.ts:81-84`), `productName` ×3 including the `aria-label` and the initial, `resellerName` (`product-view.ts:31,38,47-48`), `dropCode` (`tracking-view.ts:82`). I swept the remaining renderers: everything else interpolated is either a number through `FCFA.format`, a catalog string via `t()/tf()`, or an app-constant (`OUAGA_ZONES`, `TRACKING_STEPS`, `DEMO_SERA_QUOTE` ids, `AUDIO_NOTE_ASSETS`) — no model-string path remains raw. My original attack is inert by code path: `readFormInto` (journey.ts, unchanged) captures the raw payload → zone-chip re-render → `value="${esc(model.landmark)}"` → the payload's `"` becomes `&quot;` before `innerHTML` parses, so it stays attribute text. The new tests are non-vacuous in both directions: `location-view.test.ts` feeds **literally my payload** (`'"><img src=x onerror=alert(1)>'`) and asserts both the negative (`not.toContain('<img')`) and the positive escaped form (`&quot;&gt;&lt;img`); dropping `esc()` fails both assertions in both new tests.

**NB② — CLOSED.** The extraction is now `/name="([^"]+)"/g` over the whole rendered form — it binds `name=` on **any** element — and still asserts the exact list `['repere','indications','telephone']`; plus an outright ban `not.toMatch(/<textarea|<select/)`; plus the source word-list widened to `adresse|address|rue|street|voie|avenue`. My `<textarea name="voie_exacte">` smuggle now fails **three independent assertions** in the unit test (exact-list mismatch, textarea ban, and — for the listed words — the source regex), and the e2e locator now also counts `[name="rue"], [name="voie"], textarea, select` (journey.spec.ts:35-39).

**NB③ — CLOSED, empirically proven.** I wrote a scratchpad file mimicking the guard with a poisoned union containing `{ kind: 'sent' }` and ran `tsc --noEmit --strict` on it: **both guard assignments fail with TS2322** (`Type 'true' is not assignable to type 'never'`) — the `Extract` forbidden-kinds guard and the bidirectional exact-five-kinds bound each catch it independently. Critically, `apps/buyer-pwa/tsconfig.json` `include` lists `"test"`, so `pnpm --filter @shop-plus/buyer-pwa typecheck` — a CI gate — typechecks `test/voice-note.test.ts` and the guard is enforced at compile time, not just at test time. Current union passes (typecheck clean).

**NB④ — CLOSED.** `confirmation.titre` is now « Commande enregistrée » (register `money` retained, copy-lint green at 102 entries), the gallery caption updated and `parcours-confirmation.png` re-captured (binary changed in the delta). The walked path's confirmation screen no longer claims confirmation; the honest pending chip is unchanged and still e2e-asserted.

VERDICT: PASS

Findings on the delta:

NB① *(residual observation, out of agreed fix scope)* — one screen after the renamed confirmation, the walked path's tracking screen (`voir-suivi` → `trackingModelFor(undefined)` → step `confirmee`) still shows « Commande confirmée » as the current timeline step (`suivi.etat.confirmee`, unchanged since bcf6770). This is the coarse tracking-step *label* in the same demo-depiction class as the merged `?demo-order` states, so I do not block on it — but under the gallery caption's own standard ("rien ne se dit « confirmé » sans jambes financées") the CTO may want the walked demo's initial tracking step reviewed alongside the founder pass.

NB② *(hardening note, no failing scenario today)* — `data-delivery="${option.id}"` (`delivery-view.ts:35`) and `src="${asset}"` (`audio-note.ts:41`) interpolate strings typed as arbitrary `string` without `esc()`. Both are app-constants today (`DEMO_SERA_QUOTE`, `AUDIO_NOTE_ASSETS` — the latter null), so nothing non-constant reaches them; wrap them the day either becomes data-driven (real Séra quote ids / founder asset URLs).