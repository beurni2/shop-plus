# WO-4.4 fresh-context verifier — round 1 (at bcf6770), VERBATIM

All commands have been run and all evidence gathered. Here is my adversarial verification report.

## Evidence (all run by me, this session, repo `/home/user/shop-plus`, branch `e4/wo-4.4` @ bcf6770)

| Check | Result |
|---|---|
| `pnpm --filter @shop-plus/buyer-pwa test` | **56/56 passed** (9 files) |
| `pnpm --filter @shop-plus/buyer-pwa typecheck` | clean |
| `pnpm exec copy-lint apps/buyer-pwa/i18n/catalog.json` | **102 entries, 0 violations** |
| `node scripts/gates/pwa-payload-budget.mjs` (fresh build) | **TOTAL 12,026 B compressed** (< 307,200) · **JS 11,626 B** (≤ 153,600) — PASS |
| `PW_EXECUTABLE=/opt/pw-browsers/chromium … test:e2e` | **32/32 passed** (incl. all 4 new journey specs) |
| `git diff main...e4/wo-4.4 --stat -- apps/reseller-app packages` | **empty** — untouched |

## The four mandated attacks

**1. COMMISSION LEAK — held.** `renderProductPage` (`src/product-view.ts:43-59`) interpolates exactly four fields by name (`productName`, `resellerName`, `priceFcfa`, `inStock` as a boolean guard); no spread, no `JSON.stringify`, no `Object.entries` — a poisoned field has no path into the HTML. The negative test (`test/product-view.test.ts:23-38`) is **not vacuous**: it feeds `commissionFcfa: 2_000`, `supplierName: 'Fournisseur Sankara'`, `supplierPhone`, then asserts absence of the formatted amount, the raw digits, `commission`, `fournisseur`, `Sankara`, and the phone. A regression that renders any poisoned field, or dumps the model (key names contain "commission"), fails it. The e2e (`e2e/journey.spec.ts:27-29`) additionally asserts the rendered page body contains neither `commission` nor `fournisseur`. Bypass attempts: `demoStudioAsset` receives only `productName`; the model is never spread into it. The one soft spot is escaping, not leakage — see NB①.

**2. STREET-ADDRESS SMUGGLE — held, with a robustness gap.** The rendered form (`src/location-view.ts:68-90`) contains exactly three inputs: `repere`, `indications`, `telephone`, plus zone chips (buttons). The negative (`test/location-view.test.ts:25-38`) extracts **all** `<input name=` values and asserts the exact list `['repere','indications','telephone']` — any added input, whatever it's named (`lieu_exact` included), fails it; it also greps the source for `name="(adresse|address|rue|street)` and asserts the copy says « pas d'adresse exigée ». Gap: a `<textarea name="voie_exacte">` would evade both the input-only regex and the source word-list, and the e2e only counts `input[name="adresse"|"address"]` (`journey.spec.ts:35`). No such element exists today — NB②.

**3. VOICE ROUND-TRIP + OFFLINE HONESTY — held.** The e2e uses a real Chromium with `--use-fake-device-for-media-stream`/`--use-fake-ui-for-media-stream` (`playwright.config.ts:16-21`), makes a genuine MediaRecorder take (record 300 ms → stop → `recorded`), asserts playback via `toHaveAttribute('src', /^blob:/)` on the audio element, then re-records — this passed live. The offline test (`journey.spec.ts:93-125`) proves: banner « Hors ligne — rien n'est perdu. » shown, journey continues offline, confirmation shows the offline chip + queued voice chip, then **`setOffline(false)` → banner lifts, chip reads « En attente du réseau » and the voice note is still `queued`** — coming back online flips nothing to done. Code paths: the reducer type space (`src/voice-note.ts:15-23`) has no `sent`/`done` state; no event produces one; the `online` listener (`journey.ts:263`) only sets `state.online` and re-renders. The unit test's exhaustiveness has a hedge — NB③.

**4. PAYLOAD BY MY OWN BUILD — held.** Fresh build: `index.html` 253 B + `manifest.webmanifest` 147 B + one JS chunk 11,626 B = **12,026 B compressed total**, ~4% of the 300 KB budget; JS ~7.6% of its 150 KB budget. I verified `dist/` contains exactly those three files (styles are JS-injected; icons are inline SVG), so the gate measures everything the first load fetches, and `process.exit(1)` fires on either breach (`scripts/gates/pwa-payload-budget.mjs:46-53`). The gate is wired into `scripts/run-gates.sh` as a hard gate.

## Also checked

- **§6.3 code-last:** structurally impossible to show the code while pending — `renderTracking` (`tracking-view.ts:95-101`) renders `dropCodeBlock` only when `dropCode !== undefined && !doorPaymentPending`, else the pending door block. The exact conflict (both set) is unit-tested (`tracking-view.test.ts:51-62`, asserts `4732` and `data-role="drop-code"` absent) and e2e-tested (`journey.spec.ts:127-140`). Code is unreachable at any step other than `porte` (tested for the four earlier steps). The demo mapping has no code+pending state and `porte-b-attente` is asserted to carry no `dropCode`.
- **§6.1 carried items:** « recommandé » on Option A, both bold lines, replay line with both figures, fee warning, no « séquestre » in view or entire catalog — all still asserted in `test/checkout-view.test.ts` (passing); lock/scooter icons ride the titles, `currentColor`/`--icon-size` only, per-option audio slot renders the honest « La note vocale arrive bientôt. » placeholder with `AUDIO_NOTE_ASSETS` both `null` and a "NEVER point these at generated speech" guard asserted in source.
- **i18n:** every new string in `catalog.json` carries `register` + `screenClass` (verified in the full diff); `CatalogSchema.parse` validates; the ui-scan asserts every `t()/tf()` key resolves, dynamic families (`suivi.etat.*`, voice reasons) exist, and no inline accented French in markup. Copy-lint green.
- **Zero-hardcode scan:** green — no hex/rgb/named colors in src, only the documented 1px hairline, one documented cubic-bezier, SVG fill/stroke restricted to `none`/`currentColor`/`var(--…)`.
- **Protections sheet:** reachable from product page (unit + e2e open/close round-trip) and from every tracking step (unit loop over all 6 steps).
- **URL params are allowlisted** (`main.ts:263`, `journey.ts:69-86`): no demo param reaches `innerHTML` unsanitized.

VERDICT: PASS

NB① **Unescaped interpolation (self-XSS pattern) in the new render layer.** `readFormInto` (`journey.ts:135-143`) captures raw input values and `renderLocationForm` re-interpolates them into attribute context (`location-view.ts:80-84`, `value="${model.landmark}"`) via `container.innerHTML`. Concrete scenario: type `"><img src=x onerror=alert(1)>` into « Repère », click a zone chip (triggers re-render) — the payload executes. Today this is strictly self-inflicted on-device (no server, no persistence, URL params allowlisted), so no invariant in my authority stack is breached — but the same pattern sits in `product-view.ts:31` (`aria-label="' + productName + '"`, constant data today) and will become a stored-XSS vector the day supplier-authored product names flow in. Demand escaping before any non-constant data reaches these renderers.

NB② **Street-address negative has an element-type gap.** The exact-list assertion (`location-view.test.ts:28-29`) covers only `<input>`; a future `<textarea name="voie_exacte">` or `<select>` would evade the unit negative, the source regex (word-list misses `voie`), and the e2e count. Suggest widening the extraction to `name="…"` on any element and asserting the exact list.

NB③ **The honesty unit test hedges on exhaustiveness.** `voice-note.test.ts:29-35` iterates a hardcoded event list and asserts a hand-written `kinds` array lacks `sent`/`done` — a future `MARK_SENT` event plus a `sent` state would pass that unit test untouched. The real guard is the e2e back-online assertion (`journey.spec.ts:121-124`), which does bind behavior. Suggest a type-level exhaustiveness assertion on the reducer's unions.

NB④ **« Commande confirmée » on the walked sandbox path.** One click after choosing an option — with no payment step even depicted — the heading claims confirmation (`confirmation.titre`) while the chip beneath honestly says « En attente du réseau ». This is the same depiction class as the already-merged `?demo-order=confirmed` harness, and the entire journey sits behind `?demo-journey=`, so I do not fail it; but the screen is internally contradictory under SP-I13's "no confirmed order without the required funded legs" and worth a founder-visible wording review (e.g. « Commande enregistrée ») before this screen pattern hardens.

NB⑤ **« Paiement envoyé. L'opérateur le confirme. »** (`suivi.porte.paiement_attente`) is a demo-state depiction of a provider-pending send, consistent with the merged `door_pending` pattern and explicitly framed as unconfirmed — acceptable, noted only for completeness under the "nothing may claim envoyé" law.