# RESELLER-I18N — tf() ported, the 12 sites, loud-fail · review packet

**Tier:** 🟠 (SP#001 tail, pulled forward while the spine is canon-blocked) · **Branch:** `e7/wo-reseller-i18n` (off `main`) · **code HEAD:** `c693c45` (JOURNAL `f555fcd` doc-only beyond) · **DO NOT MERGE.**

## What & why
The reseller-app had `t()` (catalog lookup) only; every templated string was a manual `t('k').replace('{x}', v)` at the call site — a mistyped placeholder silently shipped « {amount} » on a money screen. This ports the buyer-pwa `tf(key, params)` convention, **loud-fail**: a placeholder with no value, or a param that matches no placeholder (a mistype), **THROWS**.

## Laws → where held
- **tf() loud-fail** — `src/i18n.ts` `tf()` throws on (a) an unresolved placeholder, (b) an unused/mistyped param. `test/i18n.test.ts` planted negatives assert all three throws + a clean round-trip.
- **11 sites ported, none missed** — `App.tsx`: `grep .replace('{'` → 0, `tf(` → 12 (gains.brut/part/net · vente.titre · selection.compte · share.prix/validite/code/qr_repli · ventes.net_ligne · vente.son_prix).
- **No string behavior change** — catalog byte-UNCHANGED (copy-lint 90/0); valid tf output === old `.replace` output (round-trip test).
- **Scope discipline** — diff touches only `src/i18n.ts`, `App.tsx`, `test/i18n.test.ts`, `test/qr-hub.test.ts` (the last: its wiring assertion follows the tf form). `kit.tsx:287` CountUpAmount per-frame passed-template substitution is NOT a `t(key)` site — out of the named 11, left as-is + journaled. **U+202F note carried unchanged.**

## Evidence
- `logs/warm-gates.log` — `run-gates.sh` ALL GATES GREEN (reseller-app 88/88, copy-lint 90/0).
- `logs/cold-proof.log` — fresh clone `c693c45`, credential-only baseline: frozen install rc=0, 0 ssh-form, ui-tokens 0.9.7, ALL GATES GREEN.
- `diff/reseller-i18n.*` — the full diff (4 files).
- `WO-RESELLER-I18N-VERIFIER-VERDICT-verbatim.md` (repo `_review/`) — fresh-context verdict, verbatim.

## Chain note
The spine (SP#001-A → B → D) is STOP-AND-FLAGGED on a canon gap: `StorefrontSchema` lacks `name`/`zone`/`category`/`createdAt`/`updatedAt` (see JOURNAL + the founder flag). This tail slice was pulled forward per "do not wait for rulings to keep moving." When canon ships the storefront fields, A→B→D resume.

## Verifier catch (corrected)
The first verifier pass returned **FAIL**: a 12th site (`App.tsx:398-402`, `gains.baseline_titre`, a money string) was missed — my completeness grep gave a false green because the call was **line-wrapped**. Fixed at `6ee5cd9`: the 12th site ported to `tf`, plus a **multiline-aware guard** in `test/i18n.test.ts` (asserts zero `t('k')\s*.replace(` in App.tsx). reseller-app **89/89**; warm + cold re-proven green on `e030024`. The re-issued verdict is verbatim in `_review/`.
