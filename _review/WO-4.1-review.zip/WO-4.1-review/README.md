# WO-4.1 — LE MONDE NAVIGABLE · review packet

Founder feedback driving this WO, verbatim: "i thought it was going to be like
a real app where i can scroll and see all the functionalities."

Principle: NO new business capability — merged flows became REACHABLE. Demo
mode = each repo's own real logic against in-memory sandbox stores seeded with
believable Ouagadougou demo data (every name « (démo) »-marked; every franc
through the pinned waterfall; every custody move through custody-flow.ts).

## Heads under review (branch `e4/wo-4.1`, all three repos) — DO NOT MERGE

| repo | base (main) | head | build | fixes | verifier |
|---|---|---|---|---|---|
| boutik-plus | 0ffaf3e | f916bf0 | 3c70108 | bd20230 | FAIL → fix → **PASS** (delta) |
| shop-plus | c6ffec7 | 81023bc | c5d58bf | 83f9f75 (doc word) | **PASS** (5 NB) |
| sera | 5efef1c | 52c1cff | 12dad14 | c8a5004 · ecbf32c | FAIL → fix → FAIL → fix → **PASS** (189-state BFS) |

## Evidence per repo (logs in <repo>/logs/)
- boutik-plus @ bd20230: tests 18/18 · typecheck 0 · gates green · isolated dual
  export Android 682 / iOS 684 · cold proof green (install 0, gates 0, export 0).
- shop-plus @ df3d8f5 (+doc/journal commits): tests 23/23 · typecheck 0 · gates
  green (incl. buyer-pwa gallery 9/9, zero PNG drift) · isolated dual export
  Android 583 / iOS 585 · cold proof green.
- sera @ ecbf32c (+journal commit; gates log re-cut at 52c1cff): tests 20/20 ·
  typecheck 0 · gates green (incl. console gallery 4/4) · isolated dual export
  Android 583 / iOS 585 · cold proof green.

## Money proven in-app (§5.4 worked baseline, visible on-screen)
10 000 F → productSubtotal 11 500 · buyerTotal 12 500 · sellerNet 8 500 ·
resellerNet 2 000 · platform 1 000 · delivery 1 000 outside fee bases.
Supplier offre live preview (M=0, D=0): sellerNet 8 500 = 10 000 − 500 − 1 000.
Reseller gains: net 9 520 = gross 11 900 − 20 % fee 2 380 (whole-world seeds);
baseline card net 2 000 = 2 500 − 500.

## Safest-defaults flagged ⚠ (founder rulings requested)
1. sera `retryDelivery`: retry_window → door_inspection (old shell went straight
   to 'drop'; in Option-B that could surface the drop code without the payment
   leg — SE-I11 conservative reading; rule source silent on the retry target).
2. sera « Retour » total rule: course screen → liste → accueil (two-level
   waypoint ladder; no stack pop exists — stale custody screens unreachable by
   construction, proven by the verifier's 189-state BFS).

## Galleries (missing-state law)
- shop buyer-pwa + sera console: re-captured zero-visual-drift; the RN journeys
  added as NAMED gaps. boutik has no gallery surface — its visual channel is
  WALKTHROUGH.md + Expo Go (journaled).

## The founder scripts
Each repo dir carries its app's WALKTHROUGH.md (French, step-by-step, a *Test
5 secondes* line per screen). Read them phone-in-hand against the Expo Go
previews.
