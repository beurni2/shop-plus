# Sera WO-4.1 — fresh-context verifier, DELTA round 1 (fix commit c8a5004)

Received verbatim from the verifier agent:

---

## Delta re-verification at c8a5004 — complete

**What I re-checked, each with my own evidence:**

1. **Named repros — fixed.** I replicated App.tsx's exact `go`/`back` semantics against the real `journey.ts` at c8a5004 (delta.test.ts in my scratchpad, run against a clone updated to c8a5004): back from `verify` (stack `[service, affectation, verify]`) → `['service','courses']`; back from `refusal_reason` (via drop) → `['service','courses']`. Header-back from every one of the 15 `COURSE_BACK_STEPS` screens resets to the list. `COURSE_BACK_STEPS` verified as exactly `Object.keys(JOURNEY)` minus service/courses (15 screens), superset of `COURSE_OPEN_STEPS`.
2. **No stale references.** `grep -rn SEALED_BACK_STEPS apps/rider-app/` → zero matches (not even comments).
3. **Tests/typecheck at c8a5004** in /home/user/sera: **20/20 passed**, `tsc` exit 0.
4. **WALKTHROUGH** step 4 and §6 rewritten; the old line-107 promise (« Avant le scellé … revient d'un écran, normalement ») is gone.
5. **NB②③⑤ undisturbed** (delta touches only App.tsx import+back(), the journey constant, one spine test, WALKTHROUGH step4/§6 — `JOURNEY.payment_wait`, the pay_ok seam block, and WALKTHROUGH line 8 are byte-identical). **NB④ resolved**: `git status --porcelain` is clean, HEAD = c8a5004.

**But the fix does not close the crash class.** The coordinator's premise — "no in-course screen can be reached by pop anymore" — is false. `back()` has two arms, and the pop arm still fires on the course list; the list can sit **above** in-course screens because five in-screen « Retour aux courses » buttons **push** `'courses'` via `go()` (App.tsx:279, 316, 434, 452, 464 — all unchanged by the delta). I proved the route at runtime with the real modules:

VERDICT: FAIL

1. **BLOCKING — push-then-pop still reaches a stale course screen with a throwing primary action, inside the documented §5 walk.** Route (simulated with the repo's own journey.ts, test passing): open Mariam at `refused_final` → « Préparer le retour » → « Échanger les deux codes » (App.tsx:450 `completeReturn` closes the course, App.tsx:452 `go('courses')` **pushes** the list) → header « ← Retour » on the list: `'courses' ∉ COURSE_BACK_STEPS` (journey.ts:112-114) → pop arm (App.tsx:100) reveals the stale `retour_colis` screen → press « Échanger les deux codes » again → `completeReturn` throws `custody out of order: … (closed)` (store.ts:112-116, 262-265 — throw reproduced at runtime), unhandled (App.tsx has no try/catch; index.ts registers App bare). ~6 taps. Custody is never at risk — the store refuses — but this is the same crash class the fix round was for, one route narrower. It also falsifies the **new** WALKTHROUGH.md:110 claim « Hors d'une course (la liste), « ← Retour » revient à l'accueil » — on this stack, list-back goes to `retour_colis`, not home. Minimal fix: make the five « Retour aux courses » buttons reset the stack (`setStack([START,'courses'])`) instead of pushing via `go('courses')`, or make the pop arm on `'courses'` always `setStack([START])` — either makes WALKTHROUGH:110 true by construction.

2. NB — the other four push-sources (`refused` App.tsx:279, `evidence_pending`:316, `reschedule_planned`:434, `delivered`:464) re-show via the same pop route, but those screens are static with go-only buttons — no crash, only the WALKTHROUGH:110 inaccuracy. They are cured for free by the same fix.

3. NB — prior NB② (no ladder entry from `payment_wait`), NB③ (sandbox door-signal button seam), NB⑤ (« Trois courses … plus une quatrième » phrasing) stand unchanged; prior NB④ (uncommitted PNG) is resolved.
