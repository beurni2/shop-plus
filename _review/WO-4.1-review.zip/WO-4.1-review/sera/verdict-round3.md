# Sera WO-4.1 — fresh-context verifier, DELTA round 2 (fix commit ecbf32c) — FINAL

Received verbatim from the verifier agent:

---

All four delta checks pass, and the repo suite at ecbf32c is 20/20 with typecheck exit 0. Everything the round-3 request asked for is verified:

**1. Repros (delta2.test.ts, run against a clone at ecbf32c, using the repo's real journey.ts + store.ts):**
- Round-2 repro CLOSED: Mariam `refused_final` → `prepareReturn` → `retour_colis` → `completeReturn` + `toCourses` → stack `['service','courses']` → header back → `['service']` (home). `retour_colis` is never revealed; and even hypothetically, the store still throws `(closed)` on a second `completeReturn`.
- Round-1 repros still closed: back from `verify` → `['service','courses']`; back from `refusal_reason` (via drop) → `['service','courses']`.

**2. Exhaustive route check, stated from the code:** Every stack mutation in App.tsx at ecbf32c is one of exactly five `setStack` call sites (App.tsx:87 guarded push in `go`, :92 `toCourses` → `[START,'courses']`, :103 back list-arm → `[START]`, :107 back course-arm → `[START,'courses']`, :112 `reset` → `[START]`). No `.slice(0,-1)`, `.pop(`, or `.shift(` exists anywhere in the file — structurally nothing can ever be revealed from underneath. `go('courses')` occurs exactly once, inside the `screen === 'service'` render block (App.tsx:183), so the list is only ever pushed onto the bare root; all five in-course « Retour aux courses » handlers (App.tsx:287, 324, 442, 460, 472) now call `toCourses`. On top of the case analysis, I ran a BFS over the faithful handler set (all JOURNEY-edge pushes from walk()/openCourse, courses-push only from service, toCourses, three-arm back, reset) to depth 12 — 189 distinct reachable stacks, exhaustive with the retry cycle covered twice — asserting three invariants on every state: (A) `'courses'` never sits above any course screen, (B) `'service'` only at the root, (C) `back()` never lands on a course screen. All hold.

**3. Repo gates at ecbf32c:** `pnpm test` 20/20, `pnpm typecheck` exit 0, in /home/user/sera read-only.

**4. WALKTHROUGH:110 and NBs:** the delta touches only App.tsx + test/journey-spine.test.ts (WALKTHROUGH/src/i18n: 0-line diff). « Hors d'une course (la liste), « ← Retour » revient à l'accueil » is now true by construction — the list-arm is unconditionally `setStack([START])`. NB② (`JOURNEY.payment_wait` / no ladder entry from the wait), NB③ (sandbox door-signal seam), NB⑤ (« Trois courses … plus une quatrième » phrasing) are byte-identical and undisturbed. Working tree clean, HEAD = ecbf32c.

VERDICT: PASS

1. NB — JOURNEY still declares `'courses'` as an edge from `refused`/`evidence_pending`/`delivered`/`reschedule_planned`/`retour_colis`/`affectation` (journey.ts:72-101). No handler uses those edges anymore (all go through `toCourses`), so they are inert today — and the repo's own spine test now pins `go('courses')` to exactly one occurrence (test/journey-spine.test.ts:101), so any future call that would re-open the push-then-pop route fails CI. Acceptable as-is; pruning those edges would be a cosmetic tidy, not a requirement.
2. NB — prior NB② (refusal ladder not enterable from `payment_wait` — matches the WO-2.4 shell, for the E2 ladder work), NB③ (the payment_wait « confirmed » button feeds the compile-time sandbox constant; honest labels, pending branch buttonless, store rejects non-signal values), and NB⑤ (WALKTHROUGH line 8 wording) stand unchanged as demo-level notes. NB④ (uncommitted PNG) remains resolved — `git status --porcelain` clean.
3. NB — behavior nuance, correct but worth knowing for the founder walk: back on the course list always goes home now, even mid-journey, and back on a course screen always goes to the list — the header « ← Retour » is a two-level waypoint ladder (course → liste → accueil), exactly as WALKTHROUGH §6 describes.
