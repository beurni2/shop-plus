# WO-7.0 — SHOP+ reseller on GRAND TEINT · the ui-tokens SKEW EXECUTIONER
Branch `e7/wo-7.0` off main `c8038ea` · AMBER · DO NOT MERGE (founder review)

## Headline
🔴 **The WO-5.3 per-app ui-tokens skew is DEAD.** reseller-app migrated off the
retired v0.6.0 API onto Grand Teint v0.8.0; the workspace default override is
unified at v0.8.0; the scoped `@shop-plus/buyer-pwa>@platform/ui-tokens` line is
deleted. Both app surfaces resolve 0.8.0. `grep buyer-pwa>@platform/ui-tokens
pnpm-workspace.yaml pnpm-lock.yaml` → empty (see logs/skew-kill-assertions.txt).

## What was built (the safest, non-inventing scope)
- reseller `src/ui/kit.tsx` + `App.tsx` rebuilt on the Grand Teint API
  (`theme.colours`, top-level `type/spacing/radius/touch/money/motion/interaction`),
  ink-on-paper grammar (radius 0, hairlines, NO shadows), 4px theme strip,
  token-derived `Easing.bezier` from `motion.springSoft`.
- Existing screens reskinned: S1 accueil, S2 opportunités, S4 sélection/vitrine,
  S6 gains. S5 (lien) untouched. Spine + money frozen.
- Certification transitive pinned to v0.6.0 (it declares 0.6.0; its report-html
  imports removed `neutralColors`) — dependency hygiene, not the app skew.

## Frozen (proof: logs/frozen-diff-proof.txt — git diff origin/main empty)
`src/journey.ts`, `src/earnings.ts`, `test/journey-spine.test.ts` — byte-untouched.

## Gates (logs/run-gates-full.txt): ALL GATES GREEN (exit 0)
typecheck 11/11 · tests 15/15 (reseller 43/43, buyer-pwa 71/71, commerce-core 86/86)
· drift-check 11 docs @ 0.8.0 · copy-lint reseller 40/0 · PWA payload 46,163 B < 307,200
· Playwright 38/38 · every negative fixture failed-closed.

## ⚠ FOUNDER ARBITRATION — surfaced, not resolved (see JOURNAL.md WO-7.0)
The WO named S1–S8 minus S5, but the design bundle designs only S2 + S6 for Shop+;
flows.md line 101 lists "Shop+ S1, S3, S4, S7, S8" as « restants à dessiner », and
copy.md has no strings for découverte-search / ventes / réputation. Building S3/S7/S8
would require inventing layout + French (violates derive-never-invent + the "spine
unchanged" freeze). Recommendation: split S3/S7/S8 into their own design-gated
slice(s) once Claude Design ships their mockups + copy — as S5 became RED WO-7.1.
Also deferred with that split: the première_vente celebration, exact S2/S6 mockup
states, emoji-in-chrome (undesigned S1 nav). reseller-app has no RN renderer here,
so its evidence is source + source-discipline tests, not screenshots.
