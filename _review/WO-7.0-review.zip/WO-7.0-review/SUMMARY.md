# WO-7.0 re-pin to canon v0.9.4 — nav glyphs + cold-proof law
Branch e7/wo-7.0 @ d7f0cdc off main c8038ea · DO NOT MERGE (founder review)

## The one re-pin (CTO ruling)
Every @platform/* dep + workspace override → 04af4b5 (v0.9.4). Lockfile REGENERATED
(clean HOME) → portable https-form. GUARD: ui-tokens content-proves 0.9.4. v0.9.4
supplies the nav glyphs AND dimension.iconSizePx.tab (20).

## STEP 0 probe → 0 · Cold proof → cold-installable (the SSH-form defect is fixed)
Probe (throwaway clone, clean regen, clean HOME): grep 'git@github.com:' = 0.
FULL COLD PROOF on committed bytes (logs/cold-proof.txt): frozen install rc=0,
build rc=0, all gates + Playwright 38/38, cold payload 46,163 B. (The first cold
gate run's playwright failure was an isolated-TMPDIR chromium SIGTRAP, not a code
defect — same bytes pass 38/38; documented, not hidden.)

## The emoji died — canon glyphs at the canon size
Tab bar: IconAccueil/IconProduits/IconGains at dimension.iconSizePx.tab. Vitrine
empty-state: IconVitrine. Zero emoji in chrome. 3 new SVGs byte-copied from canon;
icons regenerated to 29. Mapping note: the 'opportunites' tab (label «Opportunités»)
takes produits.svg — the products-to-resell screen you named "🛍️ produits"; gains→
gains.svg; vitrine.svg on the vitrine screen.

## Two new gates (each with a planted negative that fires)
- no-emoji-in-chrome (Grand Teint §8): apps/ carry only canon SVG glyphs.
- lockfile-url-form (cold-install law): pnpm-lock.yaml is https-form only.

## Certification override DELETED
neutralColors→sharedColour landed at v0.8.0; the bug lived only in the v0.6.0
snapshot. v0.9.4 certification resolves sharedColour; no override. commerce-core 86/86.

## Frozen · Gates · Verifier
journey/earnings/demo-store/spine byte-unchanged; money reconciles. run-gates.sh:
ALL GATES GREEN (typecheck 11/11, tests 15/15, drift 11 docs @ 0.9.4, payload 46,163 B,
Playwright 38/38). Fresh-context verifier: OVERALL: PASS (8/8 mandates).
S3/S7/S8 → WO-7.2 (design-gated); S5 → WO-7.1 (RED).
