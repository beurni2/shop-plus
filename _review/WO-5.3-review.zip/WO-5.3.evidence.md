# WO-5.3 buyer-PWA evidence — captured 2026-07-12T10:51:26Z on e5/wo-5.3 @ 01b62e3

## typecheck (buyer-pwa)

> @shop-plus/buyer-pwa@0.0.1 typecheck /home/user/shop-plus/apps/buyer-pwa
> tsc -p tsconfig.json --noEmit


## payload budget (compressed)
✓ built in 223ms
initial payload (everything the first load fetches), compressed:
  index.html: 374 B raw → 254 B gzip
  manifest.webmanifest: 187 B raw → 148 B gzip
  assets/index-jIRakFH7.js: 63001 B raw → 15406 B gzip
TOTAL: 15808 B compressed (budget: < 307200 B)
JS: 15406 B compressed (budget: ≤ 153600 B)
PWA payload budget OK

## copy-lint
copy-lint OK: 110 entries, 0 violations

## drift-check
drift-check OK: 11 canonical docs match manifest (packageVersion 0.8.0)

## unit (my run, post review-fix)
64 passed (10 files) — +1 reconcile-line assertion (2492a18), proven to bite

## e2e (my run, PW_EXECUTABLE=chromium-1194)
34 passed (19.5s) — journey walk, offline-honest, drop-code-last, ribbon-every-screen, protections, 24 gallery

## OUT-OF-SCOPE (founder arbitration): repo-wide run-gates.sh exits 1
reseller-app typecheck FAILS (App.tsx .colors/.spacing/.typeScale — old API); commerce-core test FAILS (payment-mock-certification.test.ts imports removed neutralColors; its typecheck PASSES).
Both = v0.8.0 breaking-rename consequences outside buyer-PWA scope (WO-5.0 ruling ①: apps adopt at their Grand Teint touches). Buyer PWA itself fully green.
